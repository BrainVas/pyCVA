# Add all the methods the user can use with a cave_dsa object
import cave.cave_wrapper as cave_wrapper
from . import prepare_data
import sys
import os

class cave():
        
    def __init__(self):
        """
        Initializes the Cave wrapper.
        """
        self.wrapper = cave_wrapper()

        

    def run(self, *args, **kwargs):
        """
        Runs the tool using Docker or Singularity, based on what is installed.

        Args:
            *args: Positional arguments to pass to the backend `cave_wrapper._run_docker` or `cave_wrapper._run_singularity` method.
            **kwargs: Keyword arguments to pass to the backend `cave_wrapper._run_docker` or `cave_wrapper._run_singularity` method.

        Returns:
            None

        Raises:
            RuntimeError: If neither Docker nor Singularity is installed.
        """
        return cave_wrapper.run(*args, **kwargs)
    
    def cut_seq(seq, max_len):
        """
        Recursively trims a sequence to a maximum length by removing frames with lower contrast.

        If the sequence length exceeds `max_len`, the function compares the sum of pixel values
        of the first and last frames and removes the frame with the smaller sum (assumed to have
        less contrast). This process repeats recursively until the sequence length is at most `max_len`.

        Args:
            seq (numpy.ndarray): Input sequence of shape (frames, ...), e.g. (N, height, width).
            max_len (int): Maximum allowed length for the sequence.

        Returns:
            numpy.ndarray: Trimmed sequence with length less than or equal to `max_len`.
        """
        return prepare_data.cut_seq(seq, max_len)