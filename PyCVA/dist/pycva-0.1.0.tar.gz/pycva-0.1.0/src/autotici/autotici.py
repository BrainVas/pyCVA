# Add all the methods the user can use with an autoTICI object

import autotici.autotici_wrapper as autotici_wrapper
import autotici.phase_predict_wrapper as phase_predict_wrapper
# import registration.motion_correction as motion_correction
# import registration.prepost_registration as prepost_registration
# import registration.transformation as transformation
from .utils import utils
import sys
import os

from .registration import motion_correction
from .registration import prepost_registration
from .registration import transformation

  
class autotici():
    """
    AutoTICI medical image processing toolkit for cerebral angiographic analysis.
    
    This class provides an interface for processing medical images,
    including motion correction, registration, and various utility functions
    for analyzing cerebral angiographic sequences.
    """

    def __init__(self):
        """
        Initializes the AutoTICI as none to allow lazy loading later on.
        """
        self._autotici_wrapper = None  
        self._phase_predict_wrapper = None

    @property
    def autotici_wrapper(self):
        """
        This method ONLY runs when someone accesses self.autotici_wrapper
        """
        if self._autotici_wrapper is None:
            self._autotici_wrapper = autotici_wrapper.autotici_wrapper()
        return self._autotici_wrapper

    @property  
    def phase_predict_wrapper(self):
        """
        This method ONLY runs when someone accesses self.phase_predict_wrapper
        """
        if self._phase_predict_wrapper is None:
            self._phase_predict_wrapper = phase_predict_wrapper.phase_predict_wrapper()
        return self._phase_predict_wrapper


# Containerised functionality
    def run_autoTICI(self, *args, **kwargs):
        """
        Runs the tool using Docker or Singularity, based on what is installed.

        Args:
            *args: Positional arguments to pass to the backend `_run_docker` or `_run_singularity` method.
            **kwargs: Keyword arguments to pass to the backend `_run_docker` or `_run_singularity` method.

        Returns:
            None

        Raises:
            RuntimeError: If neither Docker nor Singularity is installed.
        """
        #return AutoTICI_Wrapper.run(*args, **kwargs)
        return self._autotici_wrapper.run(*args, **kwargs)


    def run_phase_predict(self, *args, **kwargs):
        """
        Runs the tool using Docker or Singularity, based on what is installed.

        Args:
            *args: Positional arguments to pass to the backend `_run_docker` or `_run_singularity` method.
            **kwargs: Keyword arguments to pass to the backend `_run_docker` or `_run_singularity` method.

        Returns:
            None

        Raises:
            RuntimeError: If neither Docker nor Singularity is installed.
        """
        #return Phase_Predict_Wrapper.run(*args, **kwargs)
        return self._phase_predict_wrapper.run(*args, **kwargs)

# Motion_correction.py
    def mc_image_pair(self, fixed_image, moving_image, transform='affine', resolution=6, metric=None, n_iteration=None):
      """
      Perform motion correction between a pair of images using elastix registration.

      Aligns the moving image to the fixed image using the specified transformation
      and registration parameters. Uses elastix library for robust image registration.

      Args:
         fixed_image (SimpleITK.Image): The reference/fixed image.
         moving_image (SimpleITK.Image): The image to be aligned to the fixed image.
         transform (str, optional): Type of transformation ('affine', 'rigid', 'bspline'). Defaults to 'affine'.
         resolution (int, optional): Number of resolution levels for multi-resolution registration. Defaults to 6.
         metric (list, optional): Registration metric to use. Defaults to None.
         n_iteration (list, optional): Maximum iterations per resolution level. Defaults to None.

      Returns:
         tuple (numpy.ndarray, SimpleITK.ParameterMap): Tuple of (aligned_image_array, transform_parameter_map).
      """
      return motion_correction.mc_image_pair(fixed_image, moving_image, transform, resolution, metric, n_iteration)


    def mc_sequence(self, img_seq):
      """
      Perform motion correction on a sequence of images.

      Aligns all frames in the sequence to the middle frame using bidirectional
      rigid registration. This corrects for patient motion during acquisition.

      Args:
         img_seq (numpy.ndarray): 3D array of image sequence (frames, height, width).

      Returns:
         numpy.ndarray: Motion-corrected image sequence with same dimensions as input.
      """
      return motion_correction.mc_sequence(img_seq)


   # Prepost_registration.py
    def register(self, img_fixed, img_moving):
      """
      Register two images using affine transformation with preprocessing.

      Performs image registration between fixed and moving images with Gaussian
      blur preprocessing and optimized registration parameters.

      Args:
         img_fixed (numpy.ndarray or str): Fixed/reference image or path to numpy file.
         img_moving (numpy.ndarray or str): Moving image to be registered or path to numpy file.

      Returns:
         tuple (float, SimpleITK.ParameterMap): Tuple of (metric_value, transform_parameter_map).
      """
      return prepost_registration.register(img_fixed, img_moving)


    def register_to_postEVT(self, preEVT_sequence, postEVT_sequence):
      """
      Register pre-EVT sequence to post-EVT sequence using skull-based alignment.

      Aligns pre-endovascular treatment images to post-treatment images using
      skull mask extraction and registration for accurate comparison.

      Args:
         preEVT_sequence (numpy.ndarray): Pre-treatment image sequence.
         postEVT_sequence (numpy.ndarray): Post-treatment image sequence.

      Returns:
         tuple (numpy.ndarray, numpy.ndarray): Tuple of (registered_preEVT_sequence, postEVT_sequence).
      """
      return prepost_registration.register_to_postEVT(preEVT_sequence, postEVT_sequence)


   # Transformation.py
    def warp_sequence(self, img, transformation_matrix):
      """
      Apply affine transformation matrix to warp an image sequence.

      Applies a 2x3 affine transformation matrix to each frame in the sequence
      using OpenCV's warpAffine function.

      Args:
         img (numpy.ndarray): 3D image sequence (frames, height, width).
         transformation_matrix (numpy.ndarray): 2x3 affine transformation matrix.

      Returns:
         numpy.ndarray: Transformed image sequence with same dimensions.
      """
      return transformation.warp_sequence(img, transformation_matrix)


   # Utils.py
    def normalize(self, img):
         """
         Normalise image values to range [0, 255] using OpenCV normalization.

         Uses cv.NORM_MINMAX to normalize the input image to the range [0, 255]
         and converts the output to unsigned 8-bit integers.

         Args:
            img (numpy.ndarray): Input image or sequence.

         Returns:
            numpy.ndarray: Normalized image with values in range [0, 255] as uint8.
         """
         return utils.normalize(img)


    def normalize_0_1(self, img):
         """
         Normalize image values to the range [0, 1] using OpenCV normalization.

         Uses cv.NORM_MINMAX with float32 output to normalize the input image 
         to the range [0, 1].

         Args:
            img (numpy.ndarray): Input image or sequence.

         Returns:
            numpy.ndarray: Image normalized to [0, 1] range as float32.
         """
         return utils.normalize_0_1(img)


    def remove_text_and_border(self, in_img):
         """
         Remove text annotations and borders from medical images using inpainting.

         Removes black text (intensity < MIN_VESSEL_INTENSITY), white text 
         (intensity > MAX_VALID_INTENSITY), and black border lines using 
         morphological operations and OpenCV inpainting with TELEA algorithm.

         Args:
            in_img (numpy.ndarray): Input image (2D) or sequence (3D).

         Returns:
            numpy.ndarray: Processed image with text and borders removed.

         Note:
            Uses different inpainting radii for text (3px) and borders (10px).
            Supports both 2D images and 3D sequences.

         Example:
            ```python
            autotici = AutoTICI()
            clean_img = autotici.remove_text_and_border(raw_image)
            ```
         """
         return utils.remove_text_and_border(in_img)


    def minip(self, img_seq, axis=0):
         """
         Compute minimum intensity projection along specified axis.

         Creates a 2D projection by taking the minimum intensity value
         along the specified axis of a 3D image sequence.

         Args:
            img_seq (numpy.ndarray): Image sequence.
            axis (int, optional): Axis along which to compute projection. Defaults to 0.

         Returns:
            numpy.ndarray: Minimum intensity projection image.
         """
         return utils.minip(img_seq, axis)


    def read_sequence(self, fp):
         """
         Read DICOM image sequence from file path.

         Reads a DICOM file and extracts both the pixel array and pixel spacing
         information. Handles both 2D and 3D sequences, expanding 2D to 3D if needed.

         Args:
            fp (str): File path to DICOM sequence.

         Returns:
            tuple (numpy.ndarray, float): Tuple of (image_sequence, pixel_spacing).
         """
         return utils.read_sequence(fp)


    def get_pixel_spacing_from_header(self, ds):
         """
         Extract pixel spacing information from DICOM header.

         Attempts to extract pixel spacing using multiple fallback methods:
         1. Direct PixelSpacing tag
         2. Calculated from DistanceSourceToDetector, DistanceSourceToPatient, and ImagerPixelSpacing
         3. Returns NaN if unavailable

         Args:
            ds (pydicom.Dataset): DICOM dataset object.

         Returns:
            float: Pixel spacing value (first element if array) or NaN if unavailable.
         """
         return utils.get_pixel_spacing_from_header(ds)


    def resize_to_1024(self, seq, pixel_spacing):
         """
         Resize sequence to 1024x1024 maintaining aspect ratio and updating pixel spacing.

         First pads the sequence to square dimensions, then resizes to 1024x1024.
         Updates pixel spacing proportionally based on the resize factor.

         Args:
            seq (numpy.ndarray): Input sequence.
            pixel_spacing (float): Current pixel spacing value.

         Returns:
            tuple (numpy.ndarray, float): Tuple of (resized_sequence, updated_pixel_spacing).
         """
         return utils.resize_to_1024(seq, pixel_spacing)


    def extract_skull_mask(self, sequence):
         """
         Extract skull mask from image sequence using temporal analysis.

         Creates a minimum intensity projection and identifies background regions
         by analyzing pixel value consistency across frames. Returns skull-masked
         image with background regions set to 0.

         Args:
            sequence (numpy.ndarray): Input image sequence.

         Returns:
            tuple (numpy.ndarray, float, numpy.ndarray): Tuple of (skull_masked_minip, background_intensity, background_mask).
         """
         return utils.extract_skull_mask(sequence)


    def binarize_image(self, img, thresh=0):
         """
         Convert image to binary using threshold or Otsu's method.

         If thresh=0, uses Otsu's automatic thresholding. Otherwise uses
         the specified threshold value. Input image must be uint8.

         Args:
            img (numpy.ndarray): Input image (must be uint8).
            thresh (float, optional): Threshold value for binarization (0 for Otsu's method). Defaults to 0.

         Returns:
            tuple (float, numpy.ndarray): Tuple of (threshold_value, binary_image).
         """
         return utils.binarize_image(img, thresh)


    def truncate(self, img, img_min=0, img_max=255):
         """
         Clip image values to specified range in-place.

         Modifies the input image directly by setting values below img_min to img_min
         and values above img_max to img_max.

         Args:
            img (numpy.ndarray): Input image (modified in-place).
            img_min (float, optional): Minimum value for clipping. Defaults to 0.
            img_max (float, optional): Maximum value for clipping. Defaults to 255.

         Returns:
            numpy.ndarray: Clipped image (same as input, modified in-place).
         """
         return utils.truncate(img, img_min, img_max)


    def pad_image(self, img, to=1024, cval=None):
         """
         Pad image to specified size using constant value padding.

         Centers the image in the target size by adding equal padding on opposite sides.
         If cval is None, uses the mode (most frequent value) of the image.

         Args:
            img (numpy.ndarray): Input image.
            to (int, optional): Target size for padding. Defaults to 1024.
            cval (float, optional): Constant value for padding (None for image mode). Defaults to None.

         Returns:
            numpy.ndarray: Padded image.
         """
         return utils.pad_image(img, to, cval)


    def pad_sequence(self, seq, to=1024):
         """
         Pad image sequence to specified size.

         Args:
            seq (numpy.ndarray): Input 3D image sequence.
            to (int, optional): Target size for padding. Defaults to 1024.

         Returns:
            numpy.ndarray: Padded image sequence.
         """
         return utils.pad_sequence(seq, to)


    def resize_to_target_spacing(self, seq, pixel_spacing, target_spacing=None):
      """
      Resize image sequence to achieve a target pixel spacing with cropping or padding.

      Resizes the image sequence so that the pixel spacing matches the desired target spacing.
      If the resized image is smaller than 1024x1024, it is padded to 1024.
      If larger, it is center-cropped to 1024.
      If `target_spacing` is None or equal to `pixel_spacing`, no resizing is performed.

      Args:
         seq (numpy.ndarray): Input image sequence.
         pixel_spacing (float): Current pixel spacing value.
         target_spacing (float, optional): Desired pixel spacing. Defaults to None.

      Returns:
         tuple (numpy.ndarray, float): Tuple of (resized_sequence, updated_pixel_spacing).

      """
      return utils.resize_to_target_spacing(seq, pixel_spacing, target_spacing)